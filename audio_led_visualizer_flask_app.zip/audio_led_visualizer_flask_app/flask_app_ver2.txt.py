from flask import Flask, render_template, request, redirect, url_for
import os
import threading
import numpy as np
import wave
import pyaudio
from rpi_ws281x import PixelStrip, Color

# Flask setup
app = Flask(__name__)

# LED strip configuration
LED_COUNT = 144
LED_PIN = 18
LED_FREQ_HZ = 800000
LED_DMA = 10
LED_BRIGHTNESS = 255
LED_INVERT = False
LED_CHANNEL = 0

# Initialize LED strip
strip = PixelStrip(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
strip.begin()

# Default settings
settings = {
    "brightness": 255,
    "pattern": "rainbow",
    "color": {"r": 255, "g": 255, "b": 255}
}

# Visualization control
visualization_thread = None
stop_visualization = threading.Event()

def color_wheel(pos):
    """Generate rainbow colors across 0-255 positions."""
    if pos < 85:
        return Color(pos * 3, 255 - pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return Color(255 - pos * 3, 0, pos * 3)
    else:
        pos -= 170
        return Color(0, pos * 3, 255 - pos * 3)

def single_color(r, g, b):
    """Set all LEDs to a single color."""
    for i in range(LED_COUNT):
        strip.setPixelColor(i, Color(r, g, b))
    strip.show()

def process_audio_chunk(data, strip):
    """Process a chunk of audio data and visualize it on the LEDs."""
    audio_data = np.frombuffer(data, dtype=np.int16)
    fft = np.abs(np.fft.rfft(audio_data))
    fft = fft[:LED_COUNT]
    fft_normalized = np.interp(fft, (fft.min(), fft.max()), (0, 255))

    for i in range(LED_COUNT):
        brightness = int(fft_normalized[i])
        if settings["pattern"] == "rainbow":
            color = color_wheel(i * 256 // LED_COUNT)
        elif settings["pattern"] == "single_color":
            color = Color(settings["color"]["r"], settings["color"]["g"], settings["color"]["b"])
        strip.setPixelColor(i, color)
    strip.show()

def visualize_live_audio():
    """Capture live audio and visualize it."""
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=44100, input=True, frames_per_buffer=1024)
    try:
        while not stop_visualization.is_set():
            data = stream.read(1024, exception_on_overflow=False)
            process_audio_chunk(data, strip)
    finally:
        stream.stop_stream()
        stream.close()
        p.terminate()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/settings', methods=['GET', 'POST'])
def settings_page():
    global settings
    if request.method == 'POST':
        # Update brightness
        settings["brightness"] = int(request.form.get("brightness", settings["brightness"]))
        strip.setBrightness(settings["brightness"])
        
        # Update pattern
        settings["pattern"] = request.form.get("pattern", settings["pattern"])
        
        # Update single color
        settings["color"]["r"] = int(request.form.get("red", settings["color"]["r"]))
        settings["color"]["g"] = int(request.form.get("green", settings["color"]["g"]))
        settings["color"]["b"] = int(request.form.get("blue", settings["color"]["b"]))

        # Apply single color if selected
        if settings["pattern"] == "single_color":
            single_color(settings["color"]["r"], settings["color"]["g"], settings["color"]["b"])

        return redirect(url_for('settings_page'))

    return render_template('settings.html', settings=settings)

@app.route('/stop', methods=['POST'])
def stop():
    stop_visualization.set()
    if visualization_thread:
        visualization_thread.join()
    return redirect(url_for('index'))

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000)
    finally:
        # Turn off LEDs on exit
        for i in range(LED_COUNT):
            strip.setPixelColor(i, Color(0, 0, 0))
        strip.show()
