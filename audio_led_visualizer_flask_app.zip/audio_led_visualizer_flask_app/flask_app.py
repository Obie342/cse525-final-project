from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import os
import threading
import numpy as np
import wave
import pyaudio
from rpi_ws281x import PixelStrip, Color

# Flask setup
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = './uploaded_files'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# LED strip configuration
LED_COUNT = 60
LED_PIN = 18
LED_FREQ_HZ = 800000
LED_DMA = 10
LED_BRIGHTNESS = 255
LED_INVERT = False
LED_CHANNEL = 0

# Initialize LED strip
strip = PixelStrip(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
strip.begin()

# Visualization settings
visualization_thread = None
stop_visualization = threading.Event()

def color_wheel(pos):
    if pos < 85:
        return Color(pos * 3, 255 - pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return Color(255 - pos * 3, 0, pos * 3)
    else:
        pos -= 170
        return Color(0, pos * 3, 255 - pos * 3)

def process_audio_chunk(data, strip):
    audio_data = np.frombuffer(data, dtype=np.int16)
    fft = np.abs(np.fft.rfft(audio_data))
    fft = fft[:LED_COUNT]
    fft_normalized = np.interp(fft, (fft.min(), fft.max()), (0, 255))

    for i in range(LED_COUNT):
        brightness = int(fft_normalized[i])
        color = color_wheel(i * 256 // LED_COUNT)
        strip.setPixelColor(i, Color(brightness, brightness, brightness))
    strip.show()

def visualize_audio_file(file_path):
    with wave.open(file_path, "rb") as wf:
        sample_rate = wf.getframerate()
        chunk_size = 1024

        while not stop_visualization.is_set() and (data := wf.readframes(chunk_size)):
            process_audio_chunk(data, strip)
            time.sleep(chunk_size / sample_rate)

def visualize_live_audio():
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16, channels=1, rate=44100, input=True, frames_per_buffer=1024)

    while not stop_visualization.is_set():
        data = stream.read(1024, exception_on_overflow=False)
        process_audio_chunk(data, strip)

    stream.stop_stream()
    stream.close()
    p.terminate()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/live')
def live():
    global visualization_thread
    stop_visualization.clear()
    visualization_thread = threading.Thread(target=visualize_live_audio)
    visualization_thread.start()
    return render_template('live.html')

@app.route('/file', methods=['GET', 'POST'])
def file():
    if request.method == 'POST':
        uploaded_file = request.files['file']
        if uploaded_file and uploaded_file.filename.endswith('.wav'):
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], uploaded_file.filename)
            uploaded_file.save(file_path)

            global visualization_thread
            stop_visualization.clear()
            visualization_thread = threading.Thread(target=visualize_audio_file, args=(file_path,))
            visualization_thread.start()
            return redirect(url_for('file'))
    return render_template('file.html')

@app.route('/stop')
def stop():
    stop_visualization.set()
    if visualization_thread:
        visualization_thread.join()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
